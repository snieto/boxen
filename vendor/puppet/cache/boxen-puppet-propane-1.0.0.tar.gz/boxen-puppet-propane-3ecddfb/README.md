# Propane Puppet Module for Boxen

Installs Propane App. License not included.

## Usage

```puppet
include propane
```

## Required Puppet Modules

* boxen
* stdlib

## Developing

Write code.

Run `script/cibuild`.
